package cs241.wl;

import java.util.*;
import java.io.*;

public class LexerMain {
    public static final void main(String[] args) {
        try {
            StringBuffer b = new StringBuffer();
            while(true) {
                int ch = System.in.read();
                if(ch < 0) break;
                b.append((char) ch);
            }
            String input = b.toString();
            List<Token> tokens = new Lexer().scan(input);
            tokens = new KWRecognizer().recognize(tokens);
            List<Token> newTokens = new ArrayList<Token>();
            for( Token t : tokens ) {
                if(WL.isWhitespace(t.id)) continue;
                if(t.id == Sym.BOF) continue;
                if(t.id == Sym.EOF) continue;
                newTokens.add(t);
            }
            tokens = newTokens;
            for(Token token : tokens) {
                System.out.println(token.id+" "+token.string);
            }
        }
        catch(IOException e) {throw new RuntimeException(e);}
        catch(RuntimeException e) {
            System.err.println("ERROR: "+e);
            System.exit(1);
        }

    }
}
