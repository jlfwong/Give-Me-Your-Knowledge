package mips;
import java.io.*;
import java.util.*;
import java.math.*;


public class twoints {
    private static int[] readFile( String filename, int loadAddress ) {
        ArrayList<Integer> out = new ArrayList<Integer>();
        try {
            DataInput in = new DataInputStream(new FileInputStream(filename));
            while(true) {
                out.add(in.readInt());
            }
        } catch(EOFException e) {
        } catch(IOException e) {
            System.err.println("IO error occurred reading "+filename);
            System.err.println(e);
            System.exit(-1);
        }
        // entry point is here:
        out.add(0x0000e814); // lis $29
        out.add(loadAddress);
        out.add(0x03a00009); // jalr $29
        out.add(0x6800000a); // trap 10 (halt)
        int[] ret = new int[out.size()];
        for(int i = 0; i < ret.length; i++) {
            ret[i] = out.get(i);
        }
        return ret;
    }
    private static String menext() {
       String s = "";
       try {
          int r = System.in.read();
          while (r == ' ' || r == '\n' || r == '\t' || r == '\r') {r = System.in.read();}
          while (r != -1 && r != ' ' && r != '\n' && r != '\t' && r != '\r') {s = s + (char)r; r = System.in.read();}
       } catch(java.io.IOException e) {
                        s = "";
       }
       return s;
    }
    public static final void main(String[] args) {
        if(args.length != 1 && args.length != 2) {
            System.err.println("Usage: java mips.twoints <filename> [load_address]");
            System.exit(-1);
        }
        int loadAddress = 0;
        if(args.length == 2) {
            loadAddress = parseLiteral(args[1]);
        }
        if((loadAddress%4)!=0) {
            System.err.println("Load address must be word-aligned.");
            System.exit(1);
        }
        int[] code = readFile(args[0], loadAddress);
        loadAddress /= 4;
        Program program = new Program(code.length + loadAddress);
        program.copyCode(code, loadAddress);
        //program.setStartAddress(new Constant.Addr((code.length+loadAddress-4)*4));
        program.setStartAddress(new Constant.Addr(0x81234560));
        Machine machine = null;
        try {
            machine = new StandardMachine(4*1024*1024, program);
            //machine = new StandardMachine(Common.DEFAULT_MEMORY_SIZE, program);
            machine.loadAddress = loadAddress*4;
            System.err.print("Enter value for register 1: ");
            machine.setRegister(1, parseLiteral(menext()));
            System.err.print("Enter value for register 2: ");
            machine.setRegister(2, parseLiteral(menext()));
            System.err.println("Running MIPS program.");
            Integer timeout = Integer.getInteger("mips.timeout");
            if(timeout == null) {
                while(true) {
                    machine.executeInstruction ();
                }
            } else {
                for( int i = timeout; i>0; i-- ) {
                    for(int j = 0; j < 1000000; j++) {
                        machine.executeInstruction ();
                    }
                }
                System.err.println("MIPS emulator timed out.");
            }
        } catch(MachineException.NormalTermination x) {
        } catch(MachineException x) {
            System.err.println("MIPS emulator internal error.");
            System.err.println(x);
            for(int i = 1; i < 32; i++) {
                System.err.print("$"+formatDec(i,2)+" = 0x"+formatHex(machine.getRegister(i),8)+"   ");
                if((i%4)==0) System.err.println();
            }
            System.err.println("pc  = 0x"+formatHex(machine.getPC(),8));
            System.exit(-1);
        }
        System.err.println("MIPS program completed normally.");
        for(int i = 1; i < 32; i++) {
            System.err.print("$"+formatDec(i,2)+" = 0x"+formatHex(machine.getRegister(i),8)+"   ");
            if((i%4)==0) System.err.println();
        }
        System.err.println();
    }
    private static String formatDec(int val, int digits) {
        String ret = Integer.toString(val);
        while(ret.length() < digits) ret = "0" + ret;
        return ret;
    }
    private static String formatHex(int val, int digits) {
        String ret = Integer.toHexString(val);
        while(ret.length() < digits) ret = "0" + ret;
        return ret;
    }
    private static int parseLiteral(String s) {
        int base = 10;
        if(s.length()>2 && s.charAt(0) == '0' && "xX".indexOf(s.charAt(1)) >= 0) {
            s = s.substring(2);
            base = 16;
        }
        int bits = 32;
        BigInteger x = new BigInteger(s, base);
        return (int) (x.longValue() & ((1L << bits) - 1));
    }
}

