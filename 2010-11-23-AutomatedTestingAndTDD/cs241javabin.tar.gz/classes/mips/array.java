package mips;
import java.io.*;
import java.util.*;
import java.math.*;


public class array {
    private static int[] readFile( String filename, int loadAddress ) {
        ArrayList<Integer> out = new ArrayList<Integer>();
        try {
            DataInput in = new DataInputStream(new FileInputStream(filename));
            while(true) {
                out.add(in.readInt());
            }
        } catch(EOFException e) {
        } catch(IOException e) {
            System.err.println("IO error occurred reading "+filename);
            System.err.println(e);
            System.exit(-1);
        }
        // entry point is here:
        out.add(0x0000e814); // lis $29
        out.add(loadAddress);
        out.add(0x03a00009); // jalr $29
        out.add(0x6800000a); // trap 10 (halt)
        int[] ret = new int[out.size()];
        for(int i = 0; i < ret.length; i++) {
            ret[i] = out.get(i);
        }
        return ret;
    }
    static int N;
    private static String menext() {
       String s = "";
       try {
          int r = System.in.read();
          while (r == ' ' || r == '\n' || r == '\t' || r == '\r') {r = System.in.read();}
          while (r != -1 && r != ' ' && r != '\n' && r != '\t' && r != '\r') {s = s + (char)r; r = System.in.read();}
       } catch(java.io.IOException e) {
           s = "";
       }
       return s;
    }

    public static final void main(String[] args) {
        if(args.length != 1 && args.length != 2) {
            System.err.println("Usage: java mips.array <filename> [load_address]");
            System.exit(-1);
        }
        int loadAddress = 0;
        if(args.length == 2) {
            loadAddress = parseLiteral(args[1]);
        }
        if((loadAddress%4)!=0) {
            System.err.println("Load address must be word-aligned.");
            System.exit(1);
        }
        int[] code = readFile(args[0], loadAddress);
        loadAddress /= 4;
        System.err.print("Enter length of array: ");
        N = parseLiteral(menext());
        Program program = new Program(loadAddress + code.length + N);
        program.copyCode(code, loadAddress);
        //program.setStartAddress(new Constant.Addr((code.length+loadAddress-4)*4));
        program.setStartAddress(new Constant.Addr(0x81234560));
        Machine machine = null;
        try {
            //machine = new StandardMachine(Common.DEFAULT_MEMORY_SIZE, program);
            machine = new StandardMachine(4*1024*1024, program);
            machine.loadAddress = loadAddress*4;
            machine.setRegister(1, (loadAddress+code.length)*4);
            machine.setRegister(2, N);
            for(int i = 0; i < N; i++) {
                System.err.print("Enter array element "+i+": ");
                machine.setMemory((loadAddress+code.length+i)*4, parseLiteral(menext()));
            }
            while(true) {
                machine.executeInstruction ();
            }
        } catch(MachineException.NormalTermination x) {
        } catch(MachineException x) {
            System.err.println("MIPS emulator internal error.");
            System.err.println(x);
            for(int i = 1; i < 32; i++) {
                System.err.print("$"+formatDec(i,2)+" = 0x"+formatHex(machine.getRegister(i),8)+"   ");
                if((i%4)==0) System.err.println();
            }
            System.err.println("pc  = 0x"+formatHex(machine.getPC(),8));
            System.exit(-1);
        }
        System.err.println("MIPS program completed normally.");
        for(int i = 1; i < 32; i++) {
            System.err.print("$"+formatDec(i,2)+" = 0x"+formatHex(machine.getRegister(i),8)+"   ");
            if((i%4)==0) System.err.println();
        }
        System.err.println();
    }
    private static String formatDec(int val, int digits) {
        String ret = Integer.toString(val);
        while(ret.length() < digits) ret = "0" + ret;
        return ret;
    }
    private static String formatHex(int val, int digits) {
        String ret = Integer.toHexString(val);
        while(ret.length() < digits) ret = "0" + ret;
        return ret;
    }
    private static int parseLiteral(String s) {
        int base = 10;
        if(s.length()>2 && s.charAt(0) == '0' && "xX".indexOf(s.charAt(1)) >= 0) {
            s = s.substring(2);
            base = 16;
        }
        int bits = 32;
        BigInteger x = new BigInteger(s, base);
        return (int) (x.longValue() & ((1L << bits) - 1));
    }
}

