package mips;

import java.util.*;

public abstract class Machine {
    private int pc = 0;
    private int ir = 0;
    private int lo = 0;
    private int hi = 0;
    private final int [] MEM;
    private final int [] REG = new int [Common.REGISTER_COUNT];
    private boolean printInstructions;

    public int loadAddress;

    private final Map<Integer, Trap> traps = new HashMap <Integer, Trap>();

    abstract class Trap {
        abstract void execute () throws MachineException;
    }

    public final Trap QUIT = new Trap () {
            void execute () throws MachineException.NormalTermination {
                throw new MachineException.NormalTermination ();
            }
        };

    protected void registerTrap (int i, Trap code) {
        Integer key = new Integer (i);

        if (traps.containsKey (key))
            throw new IllegalArgumentException ();
	traps.put (key, code);
    }

    Trap getTrap (int i) throws MachineException.InvalidTrap {
        Integer key = new Integer (i);
        if (traps.containsKey (key))
            return (Trap) traps.get (key);
        else
            throw new MachineException.InvalidTrap ();
    }

    private int adjustAddress (int address)
	throws MachineException.UnalignedAccess, MachineException.OutOfBounds {
        if ((address & 3) != 0)
            throw new MachineException.UnalignedAccess ();
        address >>= 2;
        if (address < 0 || address >= MEM.length)
            throw new MachineException.OutOfBounds ();
        return address;
    }

    public int getMemory (int address)
	throws MachineException.UnalignedAccess, MachineException.OutOfBounds {
        if(address == 0x81234560) return 0x0000e814; // lis $29
        if(address == 0x81234564) return loadAddress;
        if(address == 0x81234568) return 0x03a00009; // jalr $29
        if(address == 0x8123456c) return 0x6800000a; // trap 10 (halt)
        return MEM [adjustAddress (address)];
    }

    public void setMemory (int address, int value)
	throws MachineException.UnalignedAccess, MachineException.OutOfBounds {
        MEM [adjustAddress (address)] = value;
    }

    public int getRegister (int register) {
        return REG [register];
    }

    public void setRegister (int register, int value) {
        if (register != 0)
            REG [register] = value;
    }

    public void setPrintInstructions (boolean value) {
        printInstructions = value;
    }

    public boolean getPrintInstructions () {
        return printInstructions;
    }

    public int getPC () {
        return pc;
    }

    public void setPC (int value) {
        pc = value;
    }

    public int getIR () {
        return ir;
    }

    public int getHiLo (int position) {
	switch (position) {
	case 0: return lo;
	case 1: return hi;
	default: throw new IllegalArgumentException ();
	}
    }

    public void setHiLo (int position, int value) {
	switch (position) {
	case 0: lo = value; break;
	case 1: hi = value; break;
	default: throw new IllegalArgumentException ();
	}
    }

    public void executeInstruction () throws MachineException {
        ir = getMemory (pc);
        if (printInstructions) {
            System.err.println (Mnem.display (new Constant.Addr (getPC ()), ir));
        }
        pc += 4;
        Mnemonic.decode (ir).run (this, ir);
    }

    protected Machine (int size, Program prog) throws MachineException.OutOfMemory {
        MEM = new int [size];
        if (prog.getWordLength () > size)
            throw new MachineException.OutOfMemory ();
        prog.getCode (MEM);
        REG [Common.STACK_REGISTER] = MEM.length * 4;
        setPC (prog.getStartAddress ().address);
    }

    protected Machine (int size, int [] prog) throws MachineException.OutOfMemory {
        MEM = new int [size];
        if (prog.length > MEM.length)
            throw new MachineException.OutOfMemory ();
        for (int i = 0; i < prog.length; i++)
            MEM [i] = prog [i];
        REG [Common.STACK_REGISTER] = MEM.length * 4;
    }
}
